NTLab10: Number of Kids
(+ Extra credit)
n_kids.py
n_kids.txt
results.txt

Directions:
When opening and running the file "n_kids.py" the program will take the numbers from "n_kids.txt" and give the number of families, total number of kids, the average number of kids per family, maximum number of kids in a family, and the minimum number of kids in a family. After printing these results the program will then write these results in the "results.txt" file.

Challenges:
The biggest challenge I encountered was just figuring out how to write in a file, which I was able to reference from the textbook to get help with that.