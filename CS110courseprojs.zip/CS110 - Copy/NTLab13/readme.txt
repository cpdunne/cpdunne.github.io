NTLab13: Recursive Functions (+ Extra credit)
recursive_functions.py

Directions:
Run the test file: test_recursive_functions.py

Challenges:
The biggest challenge I encountered was primarily with the lists.