NTLab7: String Functions
string_functions.py

Directions:
When run through the test file (test_string_functions.py), the program will return the appropriate values in each section (including the last extra credit one).

Challenges:
I encountered a lot of challenges with this one. Unlike most labs we've done so far where we print a result, this one did not give that level feedback when running it as it is only to return values. Apart from the error messages and number score, the limited feedback in terms of output made it harder at first.