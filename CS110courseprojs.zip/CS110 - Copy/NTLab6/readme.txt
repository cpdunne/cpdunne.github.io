NTLab6: Functions
circles.py

Directions:
When prompted, enter the radius of a circle to find its circumference and area. Negative numbers are invalid, entering one will cause the program to ask you again for a radius. To quit the program, enter "0" when prompted for the radius.

Challenges:
The only challenge I encountered was figuring out how to arrange the area formula so it would execute correctly.