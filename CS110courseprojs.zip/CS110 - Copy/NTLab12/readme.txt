NTLab12: Classes & Objects (+ Extra credit)
movie_mgr.py
movie.py

Directions:
When opening movie_mgr.py the user will be prompted with "Please enter a movie title: ". After submitting an input, if the input is a valid existing movie title in the data then it will display the title, date, and director(s). If the input is "Add New" then the user will be prompted to add a new movie into the data allowing it to be searched after inputting its title, date, and director(s). Or if the user entered an invalid title then the program will return "Movie not found". After this, the program will ask "Search for another movie? ("Y", "y", "N", "n")". If the user enters "y" or "Y" then it will search for another movie. If the user enters "n" or "N" then the program will end.

Challenges:
The biggest challenge I encountered was creating an object.