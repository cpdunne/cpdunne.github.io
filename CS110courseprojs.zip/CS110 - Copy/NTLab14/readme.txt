NTLab14: Comparing Sorting Algorithms
compare_sorts.py
results.txt

Directions:
Run the file compare_sorts.py to get time it takes for merge, insertion, and bubble sort to sort the random lists with max values of 100, 1000, 10000, and 100000.

Challenges:
This took a while to sort, which it failed the first time when I was trying to do other work on my computer while waiting.