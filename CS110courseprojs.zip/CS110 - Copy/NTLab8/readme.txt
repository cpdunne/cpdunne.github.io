NTLab8: Madlibs
madlibs.py

Directions:
When prompted with "Do you want to see another version of the story?", respond with 'y' or 'yes' or 'n' or 'no' to indicate whether or not you would like to see another version of the story.

Challenges:
One challenge I encountered was accidentally making the range of the random number generator be one more larger for the max than it should be which caused an error with "list index out of range".