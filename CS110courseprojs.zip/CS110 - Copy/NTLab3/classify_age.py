age = int(input("Please enter person's age: "))

if age <= 2:
    category = 'infant'
elif age >= 2 and age < 4:
    category = 'toddler'
elif age >= 4 and age < 13:
    category = 'child'
elif age >= 13 and age < 18:
    category = 'teenager'
elif age >= 18 and age < 65:
    category = 'adult'
elif age >= 65:
    category = 'senior'

print("This person's age category:", category)