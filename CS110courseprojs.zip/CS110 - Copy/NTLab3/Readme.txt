Programs being submitted:
- Age Classifier (classify_age.py)
- Currency Conversion (convert_money.py)

(Age Classifier)
Instructions:
	When prompted with "Please enter person's age:", enter the age of the person that you would like to see its classification.
Challenges:
	At first, I missed adding the last closing parenthesis on the first line. This led to a bunch of errors and since pythonwas looking for a closed parenthesis when running, the syntax error reports were reporting other things that weren't actual errors.

(Currency Conversion)
Instructions:
	When prompted with "Which currency to convert:", please select one of the currencies provided on the list and enter the corresponding letter (ex: enter 'r' for Indian Rupees). After entering, you will receive the prompt "Amount of (chosen currency) to convert:". After receiving this, please enter the number amount of your chosen currency to convert to U.S. dollars.
Challenges:
	After doing the Age Classifier, I was more mindful of my lines and ran into far less challenges.