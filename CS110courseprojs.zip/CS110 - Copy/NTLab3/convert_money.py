# Currency conversion program 
print("""Convert currency to U.S. dollars
	e = Euros
	c = Chinese Yuan
	r = Indian Rupees
	j = Japanese Yen
	b = Bitcoin""")
currency = input("Which currency to convert: ")

if currency == 'e':
    amount = int(input("Amount of Euros to convert: "))
    US_dollars = amount * 1.21
elif currency == 'c':
    amount = int(input("Amount of Chinese Yuan to convert: "))
    US_dollars = amount * 0.16
elif currency == 'r':
    amount = int(input("Amount of Indian Rupees to convert: "))
    US_dollars = amount * 0.014
elif currency == 'j':
    amount = int(input("Amount of Japanese Yen to convert: "))
    US_dollars = amount * 0.0096
elif currency == 'b':
    amount = int(input("Amount of Bitcoin to convert: "))
    US_dollars = amount * 46284.1


print("In U.S. dollars, that is $", US_dollars, sep="")