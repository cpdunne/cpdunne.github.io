NTLab4: turtles
squares.py

Directions:
When prompted, input the number of squares you want to be drawn and press 'Enter'. When done, click anywhere on the yellow turtle graphics screen to close it.

Challenge:
The biggest challenge I encountered was I approached thinking about the algorithm wrong, where I imagined the number of squares adding as it would draw instead of subtracting. This meant I approached it thinking I could set a parameter detecting if the number of squares left were positive, which wouldn't work in many instances.