NTLab9: Weather App
weather.py

Directions:
When prompted with "Find temperature in cities worldwide... Please enter a city and country", please enter a city. After entering, please enter a country. This will display the maximum, minimum, and current temperature in the area. You will then be prompted with "Check weather in another city? (Y or N): ". Please respond with 'Y' or 'N' to indicate whether or not you would like to check the weather in another city.

Challenges:
The biggest challenge I encountered was just setting up and installing pip and PyOWM. The technical problems made this take a lot longer.