x = int(input("Enter first number: "))	#comment
y = int(input("Enter second number: "))
print("The sum is:", x + y)