NTLab11: Stock Market App
stock_market.py
stock_prices.txt

Directions:
When opening the user will be prompted with "Enter stock symbol: ". After entering, input validation will occur. If there is no stock symbol associated to the input, the program will inform the user and ask if they would like to try another. If the user input is valid, then the program will display and print the stock symbol, last close, open, high, low, and current as well as appending the same information into the file "stock_prices.txt". The user will then be asked if they would like to check another stock price.

Challenges:
The biggest challenge I encountered was figuring out how to find each price no matter how they are ordered.