NTLab5: while-loops
pokemon.py

Directions:
When prompted, enter the corresponding number (1-5) of the pokemon you would like to collect. Then, enter the number of them you would like to collect. After this you will be brought back to the main menu where you can make another selection. If you would like to exit and see your total pokemon, enter 5 while in the menu.

Challenges:
The main challenge I encountered was the order of my conditional and loop statements.