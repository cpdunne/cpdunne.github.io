print("Welcome to the CS 110 Pokemon Go Shop!")
userinput = int(input("Which Pokemon would you like to collect?\n\t1. Bulbasaur\n\t2. Pidgey\n\t3. Butterfree \n\t4. Sandslash\n\t5. Exit \nPlease enter your choice (1-5):"))

bulb_num = 0
pidgey_num = 0
butter_num = 0
sand_num = 0


while True:
	if userinput >= 1 and userinput <= 5:
		if userinput == 1:
			pokemon_num = int(input("How many Bulbasaur would you like to collect?"))
			bulb_num += pokemon_num
		elif userinput == 2:
			pokemon_num = int(input("How many Pidgey would you like to collect?"))
			pidgey_num += pokemon_num
		elif userinput == 3:
			pokemon_num = int(input("How many Butterfree would you like to collect?"))
			butter_num += pokemon_num
		elif userinput == 4:
			pokemon_num = int(input("How many Sandslash would you like to collect?"))
			sand_num += pokemon_num
		elif userinput == 5:
			print("Total Pokemon: \n\tBulbasaur =", bulb_num, "\n\tPidgey =", pidgey_num, "\n\tButterfree =", butter_num, "\n\tSandslash =", sand_num)
			break
	else:
		print("Input is invalid!")
	userinput = int(input("Which Pokemon would you like to collect?\n\t1. Bulbasaur\n\t2. Pidgey\n\t3. Butterfree \n\t4. Sandslash\n\t5. Exit \nPlease enter your choice (1-5):"))

