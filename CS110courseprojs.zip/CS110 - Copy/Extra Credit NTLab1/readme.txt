Extra Credit NTLab1
polygon.py

Directions:
When prompted, enter the number of sides of a regular polygon. Inputs below 3 or above 25 are invalid and the program will ask you again for the number of sides of a regular polygon.

Challenges:
A challenge I faced was that I messed up the formula for determining the interior angles.