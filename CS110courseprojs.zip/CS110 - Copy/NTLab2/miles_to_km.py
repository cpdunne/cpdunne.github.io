miles = float(input("Enter miles: "))
kilometers = miles * 1.61
print("That equals", kilometers, "kilometers")